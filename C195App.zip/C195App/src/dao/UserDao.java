package dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;
import model.User;
import utils.DBConnection;
import utils.DBQuery;

import java.sql.*;

public class UserDao {
    private Connection conn = DBConnection.getConnnection();
    private User user;
    private ObservableList<User> userList = FXCollections.observableArrayList();


    public ObservableList<User> selectAllUsers(){
        String selectAll = "SELECT * FROM users";
        try{
            DBQuery.setPreparedStatement(conn, selectAll);
        } catch (SQLException e){
            e.printStackTrace();
        }
        PreparedStatement psAllUsers = DBQuery.getPreparedStatement();
        try{
            psAllUsers.execute();
        } catch (SQLException e){
            e.printStackTrace();
        }
        try{
            ResultSet rs = psAllUsers.getResultSet();
            while(rs.next()){
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");

                user = new User(userID, userName, password, createDate, createdBy, lastUpdate, lastUpdatedBy);
                userList.add(user);
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
        return userList;
    }

    public ObservableList<User> selectUser(){

        String userSelectStatement = "SELECT * FROM users";
        try {
            DBQuery.setPreparedStatement(conn, userSelectStatement);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        PreparedStatement psUser = DBQuery.getPreparedStatement();
        try {
            psUser.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            ResultSet rsUser = psUser.getResultSet();

            while(rsUser.next()){
                int userID = rsUser.getInt("User_ID");
                String userName = rsUser.getString("User_Name");
                String password = rsUser.getString("Password");
                Timestamp createDate = rsUser.getTimestamp("Create_Date");
                String createdBy = rsUser.getString("Created_By");
                Timestamp lastUpdate = rsUser.getTimestamp("Last_Update");
                String lastUpdatedBy = rsUser.getString("Last_Updated_By");

                User user = new User(userID, userName, password, createDate, createdBy, lastUpdate, lastUpdatedBy);
                this.userList.add(user);
            }
            //DBConnection.closeConnection();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return userList;
    }

}
