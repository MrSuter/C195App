package model;

public class ModifyAppointment {
    Appointment modifyAppointment;

    public Appointment getModifyAppointment() {
        return modifyAppointment;
    }

    public void setModifyAppointment(Appointment modifyAppointment) {
        this.modifyAppointment = modifyAppointment;
    }
}
