package controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.chrono.ChronoZonedDateTime;
import java.util.ResourceBundle;

import dao.AppointmentDao;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;
import model.Appointment;

public class ReportsScreenController {

    private int planningQuantity;
    private int deBriefingQuantity;
    private int lunchQuantity;

    public int getPlanningQuantity() {
        return planningQuantity;
    }

    public void setPlanningQuantity(int planningQuantity) {
        this.planningQuantity = planningQuantity;
    }

    public int getDeBriefingQuantity() {
        return deBriefingQuantity;
    }

    public void setDeBriefingQuantity(int deBriefingQuantity) {
        this.deBriefingQuantity = deBriefingQuantity;
    }

    public int getLunchQuantity() {
        return lunchQuantity;
    }

    public void setLunchQuantity(int lunchQuantity) {
        this.lunchQuantity = lunchQuantity;
    }
    TotalAppointmentReportController totalAppointmentReportController = new TotalAppointmentReportController();
    AppointmentDao appointmentDao = new AppointmentDao();
    ObservableList<Object> allAppointmentsList = appointmentDao.getAllRecords();


    ObservableList<Appointment> planningSessionAppointments = FXCollections.observableArrayList();
    ObservableList<Appointment> deBriefingAppointments = FXCollections.observableArrayList();
    ObservableList<Appointment> lunchAppointments = FXCollections.observableArrayList();
    ObservableList<Appointment> currentMonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus1MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus2MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus3MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus4MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus5MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus6MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus7MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus8MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus9MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus10MonthList = FXCollections.observableArrayList();
    ObservableList<Appointment> plus11MonthList = FXCollections.observableArrayList();





    @FXML
    private TableColumn<Appointment, String> contactColumn;

    @FXML
    private TableColumn<Appointment, Integer> appointmentIDColumn;

    @FXML
    private TableColumn<Appointment, String> titleColumn;

    @FXML
    private TableColumn<Appointment, String> typeColumn;

    @FXML
    private TableColumn<Appointment, String> descriptionColumn;

    @FXML
    private TableColumn<Appointment, LocalDateTime> startColumn;

    @FXML
    private TableColumn<Appointment, LocalDateTime> endColumn;

    @FXML
    private TableColumn<Appointment, String> customerColumn;

    @FXML
    private TableColumn<ReportsScreenController, String> colType;

    @FXML
    private TableColumn<ReportsScreenController, Integer> colQuantity;




    @FXML
    private Button totalAppointmentsBtn;


    @FXML // Back to main screen button
    void goToMainScreen(ActionEvent event) throws IOException {
        Navigation.toMainScreen(event);
    }

    @FXML
    void goToUserSchedule(ActionEvent event) throws IOException {
        Navigation.toUserScheduleReport(event);
    }

    @FXML //Total number of customer appointments by type and month
    void showTotalAppointments(ActionEvent event) throws IOException {
        LocalDate currentDate = LocalDate.now();
        Month currentMonth = currentDate.getMonth();

        for(Object o : allAppointmentsList){
            Appointment a = (Appointment) o;
            String type = a.getType();
            if(type.equals("Planning Session")){
                planningSessionAppointments.add(a);
            } else if(type.equals("De-Briefing")){
                deBriefingAppointments.add(a);
            } else if(type.equals("Lunch")){
                lunchAppointments.add(a);
            } else {
                System.out.println("Type does not exist: " + type);
            }
            Month month = a.getZdtStart().getMonth();
            if(a.getZdtStart().isAfter(ZonedDateTime.now().minusDays(1))){
                if(month.equals(currentMonth)){
                    currentMonthList.add(a);
                } else if(month.equals(currentMonth.plus(1))){
                    plus1MonthList.add(a);
                } else if(month.equals(currentMonth.plus(2))){
                    plus2MonthList.add(a);
                } else if(month.equals(currentMonth.plus(3))){
                    plus3MonthList.add(a);
                } else if(month.equals(currentMonth.plus(4))){
                    plus4MonthList.add(a);
                } else if(month.equals(currentMonth.plus(5))){
                    plus5MonthList.add(a);
                } else if(month.equals(currentMonth.plus(6))){
                    plus6MonthList.add(a);
                } else if(month.equals(currentMonth.plus(7))){
                    plus7MonthList.add(a);
                } else if(month.equals(currentMonth.plus(8))){
                    plus8MonthList.add(a);
                } else if(month.equals(currentMonth.plus(9))){
                    plus9MonthList.add(a);
                } else if(month.equals(currentMonth.plus(10))){
                    plus10MonthList.add(a);
                } else if(month.equals(currentMonth.plus(11))){
                    plus11MonthList.add(a);
                }
            }
        }

        long current = currentMonthList.stream().count();

        System.out.println("Planning sessions: " + planningSessionAppointments.stream().count());
        System.out.println("De-Briefing sessions: " + deBriefingAppointments.stream().count());
        System.out.println("Lunch sessions: " + lunchAppointments.stream().count());
        System.out.print(currentMonth + " appointments "); System.out.println(current);

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/TotalAppointmentReport.fxml"));
        loader.load();
        totalAppointmentReportController = loader.getController();
        totalAppointmentReportController.setDeBriefingQuantity((int) deBriefingAppointments.stream().count());
        totalAppointmentReportController.setLunchQuantity((int) lunchAppointments.stream().count());
        totalAppointmentReportController.setPlanningQuantity((int) planningSessionAppointments.stream().count());

        totalAppointmentReportController.setMonth0(String.valueOf(currentMonth));
        totalAppointmentReportController.setMonth1(String.valueOf(currentMonth.plus(1)));
        totalAppointmentReportController.setMonth2(String.valueOf(currentMonth.plus(2)));
        totalAppointmentReportController.setMonth3(String.valueOf(currentMonth.plus(3)));
        totalAppointmentReportController.setMonth4(String.valueOf(currentMonth.plus(4)));
        totalAppointmentReportController.setMonth5(String.valueOf(currentMonth.plus(5)));
        totalAppointmentReportController.setMonth6(String.valueOf(currentMonth.plus(6)));
        totalAppointmentReportController.setMonth7(String.valueOf(currentMonth.plus(7)));
        totalAppointmentReportController.setMonth8(String.valueOf(currentMonth.plus(8)));
        totalAppointmentReportController.setMonth9(String.valueOf(currentMonth.plus(9)));
        totalAppointmentReportController.setMonth10(String.valueOf(currentMonth.plus(10)));
        totalAppointmentReportController.setMonth11(String.valueOf(currentMonth.plus(11)));

        totalAppointmentReportController.setMonth0Qty((int) currentMonthList.stream().count());
        totalAppointmentReportController.setMonth1Qty((int) plus1MonthList.stream().count());
        totalAppointmentReportController.setMonth2Qty((int) plus2MonthList.stream().count());
        totalAppointmentReportController.setMonth3Qty((int) plus3MonthList.stream().count());
        totalAppointmentReportController.setMonth4Qty((int) plus4MonthList.stream().count());
        totalAppointmentReportController.setMonth5Qty((int) plus5MonthList.stream().count());
        totalAppointmentReportController.setMonth6Qty((int) plus6MonthList.stream().count());
        totalAppointmentReportController.setMonth7Qty((int) plus7MonthList.stream().count());
        totalAppointmentReportController.setMonth8Qty((int) plus8MonthList.stream().count());
        totalAppointmentReportController.setMonth9Qty((int) plus9MonthList.stream().count());
        totalAppointmentReportController.setMonth10Qty((int) plus10MonthList.stream().count());
        totalAppointmentReportController.setMonth11Qty((int) plus11MonthList.stream().count());

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();




    }

    @FXML // Individual Contact schedule report. include appointment ID, title, type, description, start date and time, end date and time, and customer ID
    void showContactSchedule(ActionEvent event) throws IOException {
        Navigation.toContactScheduleReportScreen(event);
    }

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }
}