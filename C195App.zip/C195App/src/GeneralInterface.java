import model.User;

public interface GeneralInterface {
    //abstract void setUser(User user);
    // int value returning abstract method
    // int calculateSquare(int n);

    // double value returning abstract method
    //double calculateSquare(double n);

    // String object returning abstract method
    //String getMessage(String s);

    //void abstract method
    //void displayMessage(String s);

    // multiple parameter abstract method
    //int calculation(int n1, int n2);

    // no parameter abstract method
    //void displayMessage();

    //single parameter abstract method
    //int calculateSquare(int n);
}
